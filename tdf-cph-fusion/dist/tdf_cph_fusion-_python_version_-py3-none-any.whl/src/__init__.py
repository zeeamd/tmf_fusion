# -*- coding: utf-8 -*-
"""
Created on Thu Jul  5 14:40:00 2018

@author: tued7001
"""

